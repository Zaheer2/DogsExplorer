//
//  DogVisualsCollectionViewCell.swift
//  DogsExplorer
//
//  Created by User on 2022-02-02.
//

import UIKit

class DogVisualsCollectionViewCell:
    UICollectionViewCell {
    @IBOutlet weak var imageView_DogImage : UIImageView!
    
    override class func awakeFromNib() {
    }
}
