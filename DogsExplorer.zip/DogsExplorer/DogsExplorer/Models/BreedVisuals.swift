//
//  BreedVisuals.swift
//  DogsExplorer
//
//  Created by User on 2022-02-02.
//

import Foundation

// MARK: - BreedVisuals
struct BreedVisuals: Codable {
    let message: [String]
    let status: String
}
