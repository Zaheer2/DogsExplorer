//
//  BreedsList.swift
//  DogsExplorer
//
//  Created by User on 2022-02-02.
//

import Foundation

// MARK: - BreedsList
struct BreedsList: Codable {
    let message: [String: [String]]
    let status: String
}
