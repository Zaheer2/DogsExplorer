//
//  TargetSpecificConfigs.swift
//  DogsExplorer
//
//  Created by User on 2022-02-02.
//

import UIKit

struct TargetSpecificConfigs {
    static var primary_Bg : UIColor = UIColor(red: 0.09, green: 0.60, blue: 0.31, alpha: 1.00)
}
